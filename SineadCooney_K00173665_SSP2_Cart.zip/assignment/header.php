<?php 
echo ('<div id="header">');
    echo ('<h1 id="pagetitle">Products</h1>');
    echo ('<form method="POST" action="cart.php">');
        echo ('<button id="cartBtn">Shopping Cart</button>');
    echo ('</form>');
    echo ('<form method="POST">');
        echo ('<button id="logOutBtn" name="logOutBtn">Log Out</button>');
    echo ('</form>');
echo ('</div>');
    

?>